﻿
using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MattheMurphy_S00201014;

namespace GameUnitTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestDecreasePrice()
        {
            Game g1 = new Game();

            double expectedPrice = 40;

            g1.Price = 60;

            g1.DecreasePrice(20);

            Assert.AreEqual(expectedPrice, g1.Price);
        }

        [TestMethod]

        public void TestDecreasePart2()
        {
            Game g2 = new Game();

            double expectedPrice = 50;

            g2.Price = 80;

            g2.DecreasePrice(30);

            Assert.AreEqual(expectedPrice, g2.Price);
        }

    }
}
