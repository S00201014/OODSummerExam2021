﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

namespace MatthewMurphy_S00201014
{
    public class Game
    {
        //apply the getters and setters

        public string Name { get; set; }

        public int Metacritic_Score { get; set; }

        public string Description { get; set; }

        public string Platform { get; set; }

        public decimal Price { get; set; }

        public string Game_Image { get; set; }

        public void DecreasePrice(double number)
        {
            Price -= (decimal)number;
        }
    }

    public class GameData : DbContext
    {
        public GameData() : base("MyGameData") { }

        public DbSet<Game> Game { get; set; }
    }
}
